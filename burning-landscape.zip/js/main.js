"use strict";

import burningLandscape from './burning-landscape.js';

const game = new burningLandscape('#game');