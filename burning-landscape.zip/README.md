[![LICENSE](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)](https://github.com/belauzas/burning-landscape/blob/master/LICENSE.md)
![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)
![Gluten Status](https://img.shields.io/badge/Gluten-Free-green.svg)
[![HitCount](http://hits.dwyl.com/belauzas/burning-landscape.svg)](http://hits.dwyl.com/belauzas/burning-landscape)

# Burning landscape

This project is my first attemp developing at a game jam "Kenney Jam 2019".

[Game is available to play](https://belauzas.github.io/burning-landscape/index.html)

#### Authors
[Rimantas](https://github.com/belauzas)
